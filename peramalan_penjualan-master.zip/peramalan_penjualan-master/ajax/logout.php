<?php 
	session_start();
	unset($_SESSION['posisi_peg']);
	unset($_SESSION['username_peg']);
	unset($_SESSION['id_peg']);
	unset($_SESSION['nama_peg']);
 ?>