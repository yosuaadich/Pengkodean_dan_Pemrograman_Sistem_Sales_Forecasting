# Folder Ajax
Berisi proses-proses yang berhubungan dengan server menggunakan ajax
