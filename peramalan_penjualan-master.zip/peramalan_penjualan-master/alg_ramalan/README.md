# Folder Algoritma Peramalan
Berisi algoritma dari metode :
- Single Moving Average (met_sma)
- Single Exponential Smoothing (met_ses)
